import React from "react"

const DataCard = () => {
  return <div>DataCard</div>
}

export default DataCard
