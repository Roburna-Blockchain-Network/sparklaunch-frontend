import React from "react"

const Connected = () => {
  return <div>index</div>
}

export default Connected
