import React from "react"

const Progressbar = ({ data }) => {
  return <div>{data}</div>
}

export default Progressbar
